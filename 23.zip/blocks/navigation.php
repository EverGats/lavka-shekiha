<div style="height:3px; background-color:#241515;"></div>
<div align="center" style="background: #eedf8e  url(../img/uzor.png); margin-top:0px; padding:4px;">
<ul class="gradient-menu blue">
<li><a href="/">Главная</a></li>
<li><a href="../katalog">Каталог</a></li>
<li><a href="../otzivi">Отзывы</a></li>
<li id='mini_hide'><a href="/">Новинки</a></li>
<li id='mini_hide'><a href="/">О продавце</a></li>
<li id='mini_hide'><a href="/poisk">Поиск</a></li>
<li id='mini_hide'><a href="#">Контакты</a></li>
<li><a class="myLinkModal" href="#"><img style="margin-top:5px;" src='../img/dop_meny.png' height='80%'/></a></li>
</ul>
</div>
<div style="height:3px; background-color:#241515;"></div>
<div id='liniya_st'></div>



<div id="myModal" class='sidebarmenu99'>
<ul> 
<li><a href="/">Главная</a></li>
<li><a href="../katalog">Каталог</a></li>
<li><a href="../katalog/?female=1">Для нее</a></li>
<li><a href="../katalog/?male=1">Для него</a></li>
<li><a href="/">Новинки</a></li>
<li><a href="/">О продавце</a></li>
<li><a href="/poisk">Поиск</a></li>
<li><a href="/">Контакты</a></li>
</ul> 

<div style='height:5px;'></div>
<div align='center'><a href="#">Вход в личный кабинет</a></div>

<span id="myModal__close" class="close">x</span>
</div>
<div id="myOverlay"></div>