<div style='height:5px;'></div>
<div id='clear'></div>						   

<div style="height:3px; background-color:#241515;"></div>
<div id='footer' align="center">
<div style='height:35px;'></div>
<div align="center" style="color:#241515; font-size:18px; padding:8px; background-color:#FFFFFF; display: inline-block; opacity: 0.95; border-radius: 5px; 
-webkit-box-shadow:0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;
-moz-box-shadow:0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;
box-shadow:0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;
-webkit-box-shadow: 0 15px 10px -10px rgba(0, 0, 0, 0.5), 0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;
-moz-box-shadow: 0 15px 10px -10px rgba(0, 0, 0, 0.5), 0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;
box-shadow: 0 15px 10px -10px rgba(0, 0, 0, 0.5), 0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;  
">
2020-<?php echo date('Y') ?> © Шейх Парфюм. <br />
Интернет-магазин нишевой европейской и арабской парфюмерии </div>
<div style='height:35px;'></div>
</div>
<div style="height:3px; background-color:#241515;"></div>
