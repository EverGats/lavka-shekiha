<?php

include ("blocks/header.php");

include "blocks/catalog.php";
include "blocks/footer.php";

?>